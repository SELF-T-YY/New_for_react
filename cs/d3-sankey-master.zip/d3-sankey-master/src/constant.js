export default function constant(x) {
  return function() {
    return x;
  };
}
